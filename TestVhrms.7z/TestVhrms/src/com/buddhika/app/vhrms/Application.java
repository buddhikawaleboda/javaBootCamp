package com.buddhika.app.vhrms;

import java.util.List;

import com.buddhika.app.vhrms.model.Employee;
import com.buddhika.app.vhrms.service.EmployeeService;
import com.buddhika.app.vhrms.service.EmployeeServiceImpl;

public class Application {

	public static void main(String[] args) {
		
		EmployeeService employeeService = new EmployeeServiceImpl();
		
		List<Employee> employees = employeeService.getAllEmployees();
		
		for(Employee employee:employees){
			System.out.println(employee.getName() + " From " + employee.getLocation());
		}		
	}
}
