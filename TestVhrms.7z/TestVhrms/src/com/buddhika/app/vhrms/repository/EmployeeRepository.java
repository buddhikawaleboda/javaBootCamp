package com.buddhika.app.vhrms.repository;

import java.util.List;

import com.buddhika.app.vhrms.model.Employee;

public interface EmployeeRepository {
	
	List<Employee> getAllEmployees();
}
