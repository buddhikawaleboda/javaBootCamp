package com.buddhika.app.vhrms.service;

import java.util.List;

import com.buddhika.app.vhrms.model.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployees();
}
