package com.buddhika.functional;

public interface FunctionalInterfacable {
	
	//Only one abstract method can have in this functional inetrface and one abstract method should be here
	
	
	/*default boolean equals(Object obj){
		
	}*/
	
	//boolean equals(Object obj);
	//public abstract boolean equals(Object obj);
	
	
	void walk(String name);
	
	static void talk(){
		System.out.println("test");
	}

}
