package com.buddhika.functional;

public class Employee implements FunctionalInterfacable {

	String name;
	String id;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	@Override
	public void walk(String name) {
		// TODO Auto-generated method stub
		
		System.out.println("At employee class "+name);
		
	}
	
	
	
	
	
}
