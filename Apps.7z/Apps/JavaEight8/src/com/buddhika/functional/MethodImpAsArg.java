package com.buddhika.functional;

public class MethodImpAsArg {

	public static void getInterface(FunctionalInterfacable fun){
		
		fun.walk("Buddhi");
	}
	
	public static void main(String[] args) {
		
		Employee employee = new Employee();
		
		getInterface(employee);		
	}
	
}
