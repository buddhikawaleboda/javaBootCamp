package com.buddhika.markerInterface;

import java.util.function.Consumer;

public class JEightProject implements Cloneable{
	
	String name;
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public static void main(String[] args) throws CloneNotSupportedException {
		
		JEightProject j = new JEightProject();
		j.setName("Manoj");
		
		JEightProject j1 = new JEightProject();
		//j1 = (JEightProject) j.clone();
		j1 = j;
		System.out.println(j1 + " Diff " + j);

	}

}
