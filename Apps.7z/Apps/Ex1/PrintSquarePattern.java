/*
 * Print a square pattern
 */
public class PrintSquarePattern {    // Save as "PrintSaurePattern.java"
   public static void main(String[] args) {
      int size = 8;
      for (int row = 1; row <= size; ++row) {     // Outer loop to print all the rows
		 
		 if ((row % 2) == 0) {   // print a leading space for even-numbered rows
			System.out.print(" ");
}
         for (int col = 1; col <= size; ++col) {  // Inner loop to print all the columns of each row
            System.out.print("# ");
         }
         System.out.println();   // A row ended, bring the cursor to the next line
      }
   }
}