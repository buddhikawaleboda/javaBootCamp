public class ConditionalOperators {
   public static void main(String[] args) {
      
	  int mark = 60;
	  //System.out.println((mark >= 50) ? "PASS" : "FAIL");
	  
	  System.out.println("The mark is " + mark);
 
      if (mark >= 60) {
         System.out.println("PASS");
      } else {
         System.out.println("FAIL");
      }
      System.out.println("DONE");
	  
   }
}