
public class Star {
	public static void main(String[] args) {
		
		for(int star = 1; star <= 2; star += 1) {
			System.out.println("*****");
			System.out.println(" *****");
		}
	}

}
