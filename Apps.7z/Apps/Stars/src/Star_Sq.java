
public class Star_Sq {
	public static void main(String[] args) {
		
		for (int star = 1; star <= 2; star += 1){
			System.out.println("********");
			for (int line = 1; line < 2; line +=1) {
				System.out.println("*      *");
			}
		}
	}

}
