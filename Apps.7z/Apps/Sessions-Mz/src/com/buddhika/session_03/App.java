package com.buddhika.session_03;

public class App {

	public static void main(String[] args) {
		
		Computer c1 = new Computer();
	}
}
