package com.buddhika.session_03;

public class Computer {
	
	/*// Normal Initialization
	int capacityOfRAM;
	int capacityOfHardDisk;*/
	
	int capacityOfRAM = calculateRAMCapacity();
	int capacityOfHardDisk;
	//static int numberOfProcessors;
	
	static int numberOfProcessors = calculateNoOfProcessors();
	
	static {
				
	}
	
	{
		
	}
	
	public Computer(){
		System.out.println("Instructor Computer");
	}
	
	public int calculateRAMCapacity() {
		//Calculation
		System.out.println("Calculating in RAM Capacity");
		return 1024;
	}
	
	public static int calculateNoOfProcessors(){
		//Calculation
		System.out.println("Calculating in Processor");
		return 10;
	}	
	
}
