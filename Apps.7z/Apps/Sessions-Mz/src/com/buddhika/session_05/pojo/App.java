package com.buddhika.session_05.pojo;

public class App {

	static int iCount = 10;
	static byte bte = 127;
	static short shrt;
	static long log;
	static char chr = 'A';
	
	public static void main(String[] args) {
		System.out.println("Char : " + chr);
		System.out.println("Byte : " + bte);
		System.out.println("Short : " + shrt);
		System.out.println("Long : " + log);
		System.out.println("Int : " + iCount);
	}
	
	
}
