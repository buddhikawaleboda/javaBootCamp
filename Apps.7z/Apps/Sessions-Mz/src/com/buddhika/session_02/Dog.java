package com.buddhika.session_02;

public class Dog {
	
	//Instance variable
	float height;
	int age;
	
	//static variables
	static int numberOfEyes = 2;
	
	// Basic Constructor
	public Dog(){
		System.out.println("Constructor Dog");
	}
}
