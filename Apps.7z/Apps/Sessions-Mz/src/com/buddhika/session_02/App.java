package com.buddhika.session_02;

public class App {
	public static void main(String[] args) {
		
		Animal a1 = new Animal();
		a1.height = 12.1f;
		a1.age = 5;
		a1.numberOfEyes = 5;
		
		System.out.println("The Animal Name : " + a1.height);
		System.out.println("The Animal Name : " + a1.age);
		System.out.println("The Animal Name : " + a1.numberOfEyes);
		
		Dog d1 = new Dog();
		d1.height = 5.2f;
		d1.age = 4;
		d1.numberOfEyes = 2;
		
		System.out.println("The Animal Name D1 : " + d1.height);
		System.out.println("The Animal Name D1 : " + d1.age);
		System.out.println("The Animal Name D1 : " + d1.numberOfEyes);
	}
}
