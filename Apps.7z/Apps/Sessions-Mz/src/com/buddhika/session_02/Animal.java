package com.buddhika.session_02;

public class Animal {
	
	//Instance variable
	float height;
	int age;
	
	//static variables
	static int numberOfEyes = 2;
	
	// Basic Constructor
	public Animal(){
		System.out.println("Constructor an Animal");
	}
	
	public Animal(int age){
		System.out.println("Constructor an Animal with Parameter Age " + age);
		this.age = age;
	}	

}
