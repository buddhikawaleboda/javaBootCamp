package com.buddhika.session_08;

public class Man extends Human {
	
	public String myName = "Manoj";
	
	public String eat(){
		return "Man Eating...";
	}
	
	public String jump(){
		System.out.println("************");
		super.eat();
		System.out.println("************^^^^^^^^^^^^^");
		return "Man Jumping";
	}

}
