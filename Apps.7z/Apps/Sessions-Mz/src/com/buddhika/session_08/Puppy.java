package com.buddhika.session_08;

public class Puppy {
	
	public Puppy(String name){
		System.out.println("Passed Name is :" + name );
	}
	
	public static void main(String[] args) {
		Puppy myPuppy = new Puppy( "tommy" );
	}

}
