package com.buddhika.session_08;

public final class DB9 extends AstonMartin {
	
	private static final String name;
	private final String test;
	
	static{
		name = "ASN";
	}
	{
		test = "Manoj";
	}
	
	public void lightsOn(){
		System.out.println("Lights On " + name);
		System.out.println("Lights On " + test);
	}
}