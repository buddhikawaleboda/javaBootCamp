package com.buddhika.session_08;

public class App {

	public static void main(String[] args) {

		/*Car car0 = new Car() {
			public void lightsOn() {
				System.out.println("Test lights worked!!");
			}
		};
		car0.breakMe();
		
		Car car1 = new Car() {
			public void lightsOn() {
				System.out.println("Lights On - Method 1");
			}
		};

		Car car2 = new Car() {
			public void breakMe() {
				super.breakMe();
				System.out.println("Break Me - Method 2");
			}

			public void lightsOn() {
				System.out.println("Lights On - Method 2");
			}
		};*/

		Human h1 = new Human();
		System.out.println("Human Name - " + h1.myName);
		System.out.println(h1.jump());
		//System.out.println(h1.eat());
		
		Man m1 = new Man();
		System.out.println("Man Name - " + m1.myName);
		System.out.println(m1.jump());
		//System.out.println(m1.eat());
		
		/*car1.breakMe();
		car1.lightsOn();

		car2.breakMe();
		car2.lightsOn();

		DB9 db9 = new DB9();
		db9.breakMe();
		db9.lightsOn();*/
	}
}