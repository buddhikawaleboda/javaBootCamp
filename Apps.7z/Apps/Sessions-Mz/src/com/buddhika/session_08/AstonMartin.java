package com.buddhika.session_08;

public class AstonMartin extends Car{

	public void lightsOn() {
		
	}
	
	public final void breakMe(){
		System.out.println("Double break or you die!");
	}
}