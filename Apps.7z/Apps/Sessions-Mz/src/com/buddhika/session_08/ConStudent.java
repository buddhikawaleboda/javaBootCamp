package com.buddhika.session_08;

public class ConStudent extends Student{

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "conStundet";
	}
	
	@Override
	public int getInt(){
		return 12;
	}
}
