package com.buddhika.session_08;

//import java.io.*;

public class TestEmployee {

	public static void main(String[] args) {
		
		Employee emp1 = new Employee("Manoj H. Photography");
		Employee emp2 = new Employee("iGlance Photography");
		
		emp1.age = 27;
		emp1.distination = "Sri Lanka - Panadura";
		emp1.salary = 700.0;
		emp1.printEmployee();
		
		emp2.age = 72;
		emp2.distination = "Sri Lanka - Kadawatha";
		emp2.salary = 999.0;
		emp2.printEmployee();
	}
}
