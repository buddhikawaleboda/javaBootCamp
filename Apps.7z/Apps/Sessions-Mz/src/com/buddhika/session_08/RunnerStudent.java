package com.buddhika.session_08;

public class RunnerStudent {

	public static void main(String[] args) {
		Student a = new ConStudent();
		
		System.out.println(a.getName());
		System.out.println(a.getInt());
	}
}
