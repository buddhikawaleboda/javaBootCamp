package com.buddhika.session_08;

public abstract class Student {

	String name;
	int age;
	
	public abstract String getName();
	
	public int getInt(){
		return 13;
	}
	
}
