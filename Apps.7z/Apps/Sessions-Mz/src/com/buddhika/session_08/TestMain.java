package com.buddhika.session_08;

public class TestMain {
	
	public void Test(){
		System.out.println("Public Test");
	}
	
	public static void main(String[] args) {
		
		TestMain t1 = new TestMain();
		t1.Test();
	}
}
