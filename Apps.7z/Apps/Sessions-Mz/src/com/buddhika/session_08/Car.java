package com.buddhika.session_08;

public abstract class Car extends Vehicle {

	public void breakMe(){
		System.out.println("Your safe!");
	}

}
