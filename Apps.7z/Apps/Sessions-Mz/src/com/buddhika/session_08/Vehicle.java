package com.buddhika.session_08;

public abstract class Vehicle {
	
	public abstract void breakMe ();
	
	public abstract void lightsOn();

}