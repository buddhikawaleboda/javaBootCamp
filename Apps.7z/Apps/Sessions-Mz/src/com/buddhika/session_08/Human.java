package com.buddhika.session_08;

public class Human {
	
	public String myName = "H1-Human One";
	
	public String eat(){
		return "Human Eating...";
	}

	public String jump(){
		return "Human Jumping";
	}
}
