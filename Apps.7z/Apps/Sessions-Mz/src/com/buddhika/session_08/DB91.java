package com.buddhika.session_08;

public class DB91 extends AstonMartin {

}