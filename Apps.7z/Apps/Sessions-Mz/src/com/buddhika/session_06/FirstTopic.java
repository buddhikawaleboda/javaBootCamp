package com.buddhika.session_06;

public class FirstTopic {
	
	public static void main(String[] args) {
		
		//Array
		//String[] names = new String[10];
		int[] ages = new int[7];
		String [] names = {"Manoj", "Mason", "Jhon"};
		
		System.out.println(names[0]);
		
		//2D Array - Define 2D Array
		//int [][] grid = new int [2][3];
		int [] [] grid = {{5,10,15},{20,25,30},{35,40,45,50}}; // This will store 3 * 3, 3 * 3 grid and 3 * 4 grid
		grid[0][0] = 10;
		
		System.out.println(grid[0][0]);
		System.out.println(ages.length);
		System.out.println(grid.length);
		
		for(int x=0; x<grid.length; x++){
			for(int y=0; y<grid[x].length; y++){
				System.out.print("|");
				System.out.print(grid[x][y]);
			}
			System.out.println("|");
		}
	}
}
