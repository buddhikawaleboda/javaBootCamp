package com.buddhika.session_06;

public class SecondTopic {
	
	static int x = 0;
	
	public static void init() {
		System.out.print("Initialize * ");
	}
	
	public static boolean condition() {
		System.out.print("Condition * ");
		return true;
	}
	
	public static void increment(){
		System.out.print("Increment * ");
	}
	
	public static void main(String[] args) {
		
		//int x = 0;
		for(init(); condition(); increment()){
			System.out.println("X = " + x + " |");
			x++;
			
			if (x==5) break;
			//System.out.println();
		}
	}
}
