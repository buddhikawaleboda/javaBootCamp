package com.buddhika.session_06;

public class ConditionalStatements {
	
	public static void main(String[] args) {
		
		/*ifElse(7);
		ifElse(20);
		ifElse(50);
		
		switchCase(10);
		switchCase(20);
		switchCase(50);*/	
		
		whileTest(3);
		
		doWhileTest(4);
		
	}
	
	public static void ifElse(int tempVal){
		if (tempVal < 10) {
			System.out.println("Matching - Less than 10");
		} 
		else if(tempVal == 20) {
			System.out.println("Else if matching - Value Equal To 20");
		}
		else {
			System.out.println("Else block executed");
		}		 
	}
	
	public static void switchCase(int iValue){
		
		switch (iValue) {
		case 10:
			System.out.println("Value 10 Executed");
			break;
			
		case 20:
			System.out.println("Value 20 Executed");
			break;
			
		default:
			System.out.println("Default block Executed");
			break;
		}
	}
	
	public static void whileTest(int iValue){
		
		while (iValue < 7) {
			System.out.println("While Testing - Value " + iValue);
			iValue++; 
		}
	}	
	
	public static void doWhileTest(int iValue){
			
		do {
			System.out.println("Do While - Value " + iValue);
			iValue++;
		} while (iValue <= 7);
	}
}