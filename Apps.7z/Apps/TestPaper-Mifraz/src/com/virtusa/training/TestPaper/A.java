package com.virtusa.training.TestPaper;

public class A extends B {

	{
		System.out.println("1");
	}

	static {
		System.out.println("2");
	}

	public A() {
		System.out.println("3");
	}

}
