package com.virtusa.training.TestPaper;

public class App_1 {
	
	public static void main(String[] args) {
		A obj1 = new A();
	}
}
