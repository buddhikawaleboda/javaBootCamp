package com.virtusa.training.TestPaper;

public class B {

	{
		System.out.println("4");
	}

	public B() {
		
		System.out.println("5");
	}

	public void print() {
		
		System.out.println("6");
	}

}
