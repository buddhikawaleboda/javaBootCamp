package com.mds.spring.practice;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextException;

public class TestSpringProject {

}
