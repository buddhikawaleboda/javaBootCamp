package com.mds.spring.practice;

public class Restaurant {

	public void greetCustomer{
		System.out.println("Welcome to Spring Restaurant");
	}
}
