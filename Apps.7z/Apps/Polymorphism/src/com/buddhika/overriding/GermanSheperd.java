package com.buddhika.overriding;

public class GermanSheperd extends Dog {
	
	public void bark(){
		System.out.println("Baw baw");
		super.bark();
	}
}
