package com.buddhika.overriding;

public class Dog {

	public void bark(){
		System.out.println("Bark");
	}
	
	public void eat(){
		System.out.println("Chaw Chaw");
	}
}
