package com.buddhika.overriding;

public class Application {
	
	public static void main(String[] args) {
		/*Dog d1 = new Dog();
		d1.bark();*/
		GermanSheperd g1 = new GermanSheperd();
		g1.bark();
	}

}
