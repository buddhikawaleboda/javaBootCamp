package com.buddhika.overloading;

public class Application {

}
