package com.buddhika.stacksort;

import java.util.Stack;

public class StackSorter {

	public static void main(String[] args) {

		int tempValue = 0;

		Stack<Integer> stack1 = new Stack<Integer>();
		Stack<Integer> stack2 = new Stack<Integer>();

		// Add values to stack1
		stack1.push(5);
		stack1.push(21);
		stack1.push(12);
		stack1.push(99);
		stack1.push(77);
		stack1.push(202);
		stack1.push(-1);

		// System.out.println(stack1); // Print bottom to Top [5, 21, 12, 99,
		// 77, 202, -1]

		// check stack1 is empty
		while (!stack1.isEmpty()) {
			tempValue = stack1.pop(); // Store values to temp value

			// check stack1 is empty && stack2 value less than temp value
			while (!stack2.isEmpty() && tempValue < stack2.peek()) {
				stack1.push(stack2.pop());
			}
			stack2.push(tempValue);
		}

		// check stack2 is not empty, print sorted stack2
		while (!stack2.isEmpty()) {
			System.out.println(stack2.pop());
		}

	}
}
