package com.buddhika.reverse;

import java.util.*;

public class ReverseByPubudu {

	public static void main(String args[]) {

		// Get the User Input
		System.out.println("Please Enter a sentence:");
		Scanner scanner = new Scanner(System.in);
		String sentence = scanner.nextLine();

		// Split the string using split function
		String[] reversearray = sentence.split(" ");

		// Reverse the string
		for (int i = reversearray.length - 1; i > 0; i--) {
			System.out.print(reversearray[i] + " ");
		}

		String reverselastword = reversearray[0];

		// Reverse the lastword
		for (int j = reverselastword.length() - 1; j >= 0; j--) {
			System.out.print(reverselastword.charAt(j));
		}
	}
}
