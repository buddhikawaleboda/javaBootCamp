package com.buddhika.reverse;

public class StatementReverse {

	public static void main(String[] args) {

		String sentence = "Kamal is Good Boy";
		String[] word = sentence.split(" ");
		String result = "";

		for (int i = word.length - 1; i >= 0; i--) {

			if (i == 0) {
				String[] lastWord = word[i].split("");

				for (int x = lastWord.length - 1; x >= 0; x--) {
					result = result + lastWord[x];
				}
			} else {
				result = result + (word[i] + " ");
			}
		}
		System.out.println(result);
	}
}
