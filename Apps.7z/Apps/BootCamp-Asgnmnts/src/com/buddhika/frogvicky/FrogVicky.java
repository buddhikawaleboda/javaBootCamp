package com.buddhika.frogvicky;

public class FrogVicky {

	public static void main(String[] args) {

		double hopps = 4;
		double rounds = Math.ceil(hopps / 3);
		int steps = (int) (hopps % 3);
		int timeSpent = 0;
		int travelDistance = 0;

		for (int i = 0; i < rounds; i++) {

			boolean isFullRound = hopps >= (i + 1) * 3;
			timeSpent = timeSpent + 1;
			travelDistance = travelDistance + 100;

			if (isFullRound || steps > 1) {
				timeSpent = timeSpent + 2;
				travelDistance = travelDistance + 50;
			}

			if (isFullRound || steps > 2) {
				timeSpent = timeSpent + 5;
				travelDistance = travelDistance + 10;
			}

		}
		System.out.println("Time Spent : " + timeSpent);
		System.out.println("Distance Travelled : " + travelDistance);

	}

}
