package com.buddhika.numberplus;

import java.util.Arrays;

public class NumberPlus{

   public static void main(String[] args) {
	
       sumOfNumbers(4, 0, 2, 7, 9, 89, 97);
	
   }
	
   public static void sumOfNumbers(int... x) {
	
      Arrays.sort(x);
      String maxNumber = String.valueOf(x[0]);
	
      for (int i = 0; i < x.length - 1; i++) {
	 maxNumber = x[i + 1] + maxNumber;
      }
      System.out.println(maxNumber);
   }

}