package com.krishantha.eventManager.service;

import com.krishantha.eventManager.model.Activity;

public interface ActivityService {

	Activity save(Activity activity);

}
