package com.krishantha.eventManager.repository;

import com.krishantha.eventManager.model.Activity;

public interface ActivityRepository {
	Activity save(Activity activity);
} 