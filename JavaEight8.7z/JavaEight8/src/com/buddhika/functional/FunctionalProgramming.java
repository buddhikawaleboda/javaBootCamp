package com.buddhika.functional;

public class FunctionalProgramming {

	static FunctionalInterfacable fp = (String name) -> {
		
		System.out.println(name + " Functional Programming");
	};
	
	
	public static void main(String[] args) {
		
		fp.walk("Manoj");
		
		Runnable rb = () -> {
			System.out.println("Thread");
		};
		
		Thread tr = new Thread(rb);
		tr.start();
		
		//FunctionalInterfacable.talk();
		
		/*FunctionalProgramming.fp.walk("Krish");
		
		List<String>values = Arrays.asList("Gayan","Pubudu","Buddika");
		
		
		values.forEach(vals);
		
		
		values.forEach(new Consumer<String>() {
			public void accept(String name) {
				
				System.out.println(name);
			};
		});*/
		
	}
	
	
	
}
