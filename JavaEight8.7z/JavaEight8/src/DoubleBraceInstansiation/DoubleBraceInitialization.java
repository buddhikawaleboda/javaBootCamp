package DoubleBraceInstansiation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DoubleBraceInitialization {

	public static void main(String[] args) {
		
		//List<String> l1 = new ArrayList(){{
		//List<String> l1 = new ArrayList<String>(){{
			/*add("Manoj");
			add("Buddhika");
			
		}};*/
		
		List<String> l1 = Arrays.asList("Kalan","Hashan");			
			
		System.out.println(l1);
	}
	
}
