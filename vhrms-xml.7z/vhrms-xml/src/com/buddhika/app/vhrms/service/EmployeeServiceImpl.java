package com.buddhika.app.vhrms.service;

import java.util.List;

import com.buddhika.app.vhrms.model.Employee;
import com.buddhika.app.vhrms.repository.EmployeeRepository;
import com.buddhika.app.vhrms.repository.HibernateEmployeeRepositoryImpl;

public class EmployeeServiceImpl implements EmployeeService {
	
	
	EmployeeRepository employeeRepository; //= new HibernateEmployeeRepositoryImpl();
	
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		System.out.println("Constructer injected");
		this.employeeRepository = employeeRepository;
	}
	
	public EmployeeRepository getEmployeeRepository() {
		return employeeRepository;
	}

	public void setEmployeeRepository(EmployeeRepository employeeRepository) {
		System.out.println("setter injected");
		this.employeeRepository = employeeRepository;
	}

	@Override
	public List<Employee> getAllEmployees(){
		return employeeRepository.getAllEmployees();
	}

}
