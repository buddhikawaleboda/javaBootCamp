package com.buddhika.app.vhrms;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.buddhika.app.vhrms.model.Employee;
import com.buddhika.app.vhrms.service.EmployeeService;
import com.buddhika.app.vhrms.service.EmployeeServiceImpl;

public class Application {

	public static void main(String[] args) {
		
		//Initialize the applicationContext xml
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//get Class and get the EmployeeService.class type
		EmployeeService employeeService = applicationContext.getBean("employeeService",EmployeeService.class);
		
//		EmployeeService employeeService = new EmployeeServiceImpl();
		List<Employee> employees = employeeService.getAllEmployees();
		
		for(Employee employee:employees){
			System.out.println(employee.getName() + " From " + employee.getLocation());
		}		
	}
}
