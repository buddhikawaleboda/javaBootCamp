package com.virtusa.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 * Configuration for Spring REST template factory.
 * <p/>
 * Properties for the REST template are defined in application.yml at app.rest-template.connection section.
 *
 * @author ddissnayake
 */
@Configuration
public class RestTemplateConfig {

    @Bean
    @ConfigurationProperties(prefix = "app.restTemplate.connection")
    public SimpleClientHttpRequestFactory customHttpRequestFactory() {
        return new SimpleClientHttpRequestFactory();
    }

    @Bean
    public RestTemplate createRestTemplate() {
        return new RestTemplate(customHttpRequestFactory());
    }
}
