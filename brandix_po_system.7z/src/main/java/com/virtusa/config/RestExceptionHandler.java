package com.virtusa.config;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.virtusa.properties.AppProperties;
import com.virtusa.properties.ExceptionHandlerProperties;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;

/**
 * Provides a uniform runtime error handler for all controllers.
 * <p/>
 * Forwarded error message format is defined in {@link ErrorResponse}. Handled exceptions, error messages and codes are
 * defined in application.yml file at app.exception-handler section.
 *
 * @author ddissnayake
 */
@ControllerAdvice
@Slf4j
public class RestExceptionHandler {

    @Autowired
    private AppProperties appProperties;

    @ExceptionHandler(value = RuntimeException.class)
    protected ResponseEntity<Object> handleRuntimeException(RuntimeException ex, WebRequest request) {
        log.error(ex.getLocalizedMessage(), ex);
        return buildResponseEntity(new ErrorResponse(appProperties.getExceptionHandlerProperties().getErrorData(ex.getClass()), ex));
    }

    private ResponseEntity<Object> buildResponseEntity(ErrorResponse errorResponse) {
        return new ResponseEntity<>(errorResponse, errorResponse.getStatus());
    }

    @Getter
    public static class ErrorResponse {

        private HttpStatus status;
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime timestamp;
        private String message;
        private String debugMessage;
        private String code;

        private ErrorResponse() {
            timestamp = LocalDateTime.now();
        }

        ErrorResponse(ExceptionHandlerProperties.ErrorData errorData, Throwable ex) {
            this();
            this.status = HttpStatus.valueOf(errorData.getStatus());
            this.code = errorData.getCode();
            this.message = errorData.getMessage();
            this.debugMessage = ex.getLocalizedMessage();
        }

    }
}