/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.virtusa.config;

import com.virtusa.properties.AppProperties;
import com.virtusa.properties.SwaggerApiInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Collections;

/**
 * Configuration for Swagger2 API documentation plugin.
 * <p/>
 * Properties for API information are defined in application.yml at app.swagger-api-info section.
 *
 * @author ddissnayake
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {

    @Autowired
    private AppProperties appProperties;

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage(appProperties.getBasePackage() + ".controller"))
                .build()
                .apiInfo(getApiInfo());
    }

    private ApiInfo getApiInfo() {
        SwaggerApiInfo apiProperties = appProperties.getSwaggerApiInfo();
        return new ApiInfo(
                apiProperties.getTitle(),
                apiProperties.getDescription(),
                apiProperties.getVersion(),
                null,
                new Contact(apiProperties.getContact().getName(), apiProperties.getContact().getUrl(), apiProperties.getContact().getEmail()),
                apiProperties.getLicense(),
                apiProperties.getLicenseUrl(),
                Collections.emptyList());
    }

}
