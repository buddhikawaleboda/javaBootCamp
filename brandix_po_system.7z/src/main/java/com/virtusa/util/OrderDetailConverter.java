package com.virtusa.util;

import com.virtusa.model.OrderDetail;

import javax.persistence.AttributeConverter;

/**
 * JPA attribute converter for OrderDetail field which is in JSON data type.
 *
 * @author ddissnayake
 */
public class OrderDetailConverter implements AttributeConverter<OrderDetail, String> {

    @Override
    public String convertToDatabaseColumn(OrderDetail attribute) {
        return JSONUtil.toJson(attribute);
    }

    @Override
    public OrderDetail convertToEntityAttribute(String dbData) {
        return JSONUtil.fromJson(OrderDetail.class, dbData);
    }
}
