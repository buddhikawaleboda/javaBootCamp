package com.virtusa.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.virtusa.exceptions.JsonToObjectConversionException;
import com.virtusa.exceptions.ObjectToJsonConversionException;

import java.io.IOException;

/**
 * JSON conversion utilities.
 *
 * @author ddissnayake
 */
public class JSONUtil {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private JSONUtil() {
    }

    /**
     * Convert Java object to JSON string
     *
     * @param object Java object
     *
     * @return JSON representation of Java object
     *
     * @throws ObjectToJsonConversionException if a conversion error occurs
     */
    public static String toJson(Object object) {
        try {
            return OBJECT_MAPPER.writeValueAsString(object);
        } catch (IOException e) {
            throw new ObjectToJsonConversionException(e);
        }
    }

    /**
     * Convert JSON string to its respective Java Object
     *
     * @param tClass Type of the Java Object to be created
     * @param json   JSON string
     *
     * @return Java representation of JSON string
     *
     * @throws JsonToObjectConversionException if a conversion error occurs
     */
    public static <T> T fromJson(Class<T> tClass, String json) {
        try {
            return OBJECT_MAPPER.readValue(json, tClass);
        } catch (IOException e) {
            throw new JsonToObjectConversionException(e);
        }
    }

}
