package com.virtusa.properties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
public class ExceptionHandlerProperties {

    private static final ErrorData DEFAULT_ERROR_DATA = new ErrorData(500, "Internal Server Error", "500");

    private Map<String, ErrorData> handlerValues = new HashMap<>();

    public ErrorData getErrorData(Class<? extends RuntimeException> exceptionClass) {
        ErrorData errorData = handlerValues.get(exceptionClass.getSimpleName());
        if (errorData == null) {
            return DEFAULT_ERROR_DATA;
        }
        return errorData;
    }

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Setter
    public static class ErrorData {

        private int status;
        private String message;
        private String code;

    }
}
