package com.virtusa.properties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GTNProperties {

    private String username;
    private String password;
    private String dataKey;
    private API api;

    @Getter
    @Setter
    public static class API {

        private String baseUrl;
        private String poType;
        private String poAmendmentType;
        private String urlFetchObject;
        private String urlQueryObject;

    }
}
