package com.virtusa.properties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SwaggerApiInfo {

    private String title;
    private String description;
    private String version;
    private String license;
    private String licenseUrl;
    private Contact contact;

    @Getter
    @Setter
    public static class Contact {
        private String name;
        private String email;
        private String url;
    }
}
