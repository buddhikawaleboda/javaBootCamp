package com.virtusa.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Container POJO for application properties defined in application.yml at app section.
 *
 * @author ddissnayake
 */
@Component
@Getter
@Setter
@ConfigurationProperties("app")
public class AppProperties {

    private String basePackage;

    private SwaggerApiInfo swaggerApiInfo;
    private ExceptionHandlerProperties exceptionHandlerProperties;
    private GTNProperties gtnProperties;
}
