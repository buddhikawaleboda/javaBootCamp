package com.virtusa.repository;

import com.virtusa.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Repository provider for user roles.
 *
 * @author smpieris
 */
public interface RoleRepository extends JpaRepository<Role, Integer> {

    Optional<Role> findByType(String type);

    Optional<Role> findById(Integer id);
}
