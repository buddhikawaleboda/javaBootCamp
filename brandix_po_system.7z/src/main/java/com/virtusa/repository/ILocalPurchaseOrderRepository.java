package com.virtusa.repository;

import com.virtusa.model.PurchaseOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Repository provider for local purchase orders.
 *
 * @author ddissnayake
 */
public interface ILocalPurchaseOrderRepository extends JpaRepository<PurchaseOrder, Integer> {

    Optional<PurchaseOrder> findByOrderUid(String uid);

}
