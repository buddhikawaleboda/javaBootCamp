package com.virtusa.exceptions;

import java.io.IOException;

/**
 * Created by delegate on 9/19/17.
 */
public class JsonToObjectConversionException extends RuntimeException {
    public JsonToObjectConversionException(IOException ex) {
        super(ex);
    }
}
