package com.virtusa.exceptions;

import java.io.IOException;

/**
 * Created by delegate on 9/19/17.
 */
public class ObjectToJsonConversionException extends RuntimeException {
    public ObjectToJsonConversionException(IOException ex) {
        super(ex);
    }
}
