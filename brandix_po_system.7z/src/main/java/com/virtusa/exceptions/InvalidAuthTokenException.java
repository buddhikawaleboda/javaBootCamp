package com.virtusa.exceptions;

/**
 * Created by delegate on 9/6/17.
 */
public class InvalidAuthTokenException extends RuntimeException {
}
