package com.virtusa.exceptions;

/**
 * Created by delegate on 9/6/17.
 */
public class GTNConnectionFailedException extends RuntimeException {
    public GTNConnectionFailedException() {
    }

    public GTNConnectionFailedException(Throwable cause) {
        super(cause);
    }
}
