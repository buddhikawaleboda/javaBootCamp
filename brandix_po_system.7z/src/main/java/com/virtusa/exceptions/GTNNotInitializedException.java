package com.virtusa.exceptions;

/**
 * Created by delegate on 9/6/17.
 */
public class GTNNotInitializedException extends RuntimeException {

    public GTNNotInitializedException() {
    }

    public GTNNotInitializedException(String message) {
        super(message);
    }
}
