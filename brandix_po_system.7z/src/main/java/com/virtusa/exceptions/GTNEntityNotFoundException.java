package com.virtusa.exceptions;

/**
 * Created by delegate on 9/6/17.
 */
public class GTNEntityNotFoundException extends RuntimeException {
    public GTNEntityNotFoundException() {
    }

    public GTNEntityNotFoundException(String message) {
        super(message);
    }
}
