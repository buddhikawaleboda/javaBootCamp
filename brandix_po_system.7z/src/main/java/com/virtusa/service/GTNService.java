package com.virtusa.service;

import com.virtusa.exceptions.GTNConnectionFailedException;
import com.virtusa.exceptions.GTNEntityNotFoundException;
import com.virtusa.exceptions.InvalidAuthTokenException;
import com.virtusa.model.InitResponse;
import com.virtusa.model.OrderDetail;
import com.virtusa.properties.AppProperties;
import com.virtusa.properties.GTNProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.PostConstruct;
import java.net.URI;
import java.nio.charset.Charset;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

/**
 * GTNexus API client to manage remote purchase orders in GTNexus.
 * <p/>
 * Handles authentication and other GTNexus API request requirements internally. Properties for those are defined in
 * application.yml at app.gtn-properties section.
 *
 * @author ddissnayake
 */
@Service
@Slf4j
public class GTNService {

    private static final int MAX_RETRY_COUNT = 3;

    @Autowired
    private AppProperties appProperties;
    @Autowired
    private RestTemplate rest;
    private GTNProperties gtnProperties;
    private String baseUrl;
    private String authToken;
    private HttpHeaders authTokenHeader;
    private AtomicInteger retryCount = new AtomicInteger(0);
    private HttpEntity<String> httpEntityWithAuthHeader;
    private boolean tryingAuthTokenReload;

    @PostConstruct
    private void initProperties() {
        gtnProperties = appProperties.getGtnProperties();
        baseUrl = String.format("%s?datakey=%s", gtnProperties.getApi().getBaseUrl(), gtnProperties.getDataKey());
        log.debug("Base URL loaded: " + baseUrl);
    }

    public void setHttpEntityWithAuthHeader(HttpEntity<String> httpEntityWithAuthHeader) {
        this.httpEntityWithAuthHeader = httpEntityWithAuthHeader;
    }

    private HttpHeaders createBasicAuthHeaders(String username, String password) {
        return new HttpHeaders() {{
            String auth = username + ":" + password;
            byte[] encodedAuth = Base64Utils.encode(auth.getBytes(Charset.forName("UTF-8")));
            set("Authorization", "Basic " + new String(encodedAuth));
        }};
    }

    private HttpHeaders getAuthTokenHeaders() {
        if (authTokenHeader == null) {
            authTokenHeader = new HttpHeaders() {{
                set("Authorization", authToken);
            }};
        }
        return authTokenHeader;
    }

    private URI generateURI(String uriFormat, Object... param) {
        UriComponentsBuilder builder = UriComponentsBuilder
                .fromUriString(String.format(uriFormat,
                        gtnProperties.getApi().getBaseUrl(),
                        gtnProperties.getDataKey()));
        return builder.buildAndExpand(param).toUri();
    }

    private <T> T retryOnAuthError(RuntimeException ex, Supplier<T> retryFunction) {
        log.debug("retrying on auth error: " + retryCount.get());
        if (retryCount.incrementAndGet() == MAX_RETRY_COUNT) {
            retryCount.set(0);
            throw ex;
        }
        try {
            TimeUnit.SECONDS.sleep(2 * retryCount.get());
            reloadAuthToken().get();
            return retryFunction.get();
        } catch (InterruptedException | ExecutionException e) {
            retryCount.set(0);
            throw ex;
        }
    }

    private OrderDetail retryWithPOType(String uid) {
        try {
            log.info("retrying with PO type");
            URI uri = generateURI(gtnProperties.getApi().getUrlFetchObject(), gtnProperties.getApi().getPoType(), uid);
            log.debug("URL: " + uri);
            log.debug("Header: " + httpEntityWithAuthHeader.getHeaders());
            ResponseEntity<OrderDetail> orderDetailResponse = rest.exchange(
                    uri,
                    HttpMethod.GET,
                    httpEntityWithAuthHeader,
                    OrderDetail.class);
            retryCount.set(0);
            return orderDetailResponse.getBody();
        } catch (HttpStatusCodeException ex) {
            int statusCode = ex.getStatusCode().value();
            switch (statusCode) {
                case 401:
                    return retryOnAuthError(ex, () -> retryWithPOType(uid));
                case 404:
                    throw new GTNEntityNotFoundException("OrderDetail#" + uid);
                default:
                    throw ex;
            }
        }
    }

    /**
     * Checks the ready state of GTNService for requests via availability of authentication token; Returns false if the
     * auth token is not yet loaded.
     *
     * @return is GTNService ready to accept requests
     */
    public boolean isInitialized() {
        if (authToken != null) {
            return true;
        }
        if (!tryingAuthTokenReload) {
            try {
                reloadAuthToken();
            } catch (RuntimeException e) {
                throw new GTNConnectionFailedException(e);
            }
        }
        return false;
    }

    /**
     * Initializes loading auth token from GTN service. This will be executed asynchronously and once the token is
     * received, HTTP headers to be used in further requests will be generated.
     *
     * @return Future with received auth token
     */
    @Async
    public Future<String> reloadAuthToken() {
        tryingAuthTokenReload = true;
        log.info("Reloading auth token");
        log.debug("URL: " + baseUrl);
        HttpHeaders basicAuthHeaders = createBasicAuthHeaders(gtnProperties.getUsername(), gtnProperties.getPassword());
        log.debug("Headers: " + basicAuthHeaders);
        try {
            HttpEntity<InitResponse> response = rest.exchange(
                    baseUrl,
                    HttpMethod.GET,
                    new HttpEntity<String>(basicAuthHeaders),
                    InitResponse.class);
            HttpHeaders headers = response.getHeaders();
            authToken = headers.get("Authorization").stream()
                    .findFirst()
                    .map(t -> t.split(" ")[1])
                    .orElseThrow(InvalidAuthTokenException::new);
            log.debug("Auth token loaded: " + authToken);
            setHttpEntityWithAuthHeader(new HttpEntity<>(getAuthTokenHeaders()));
            log.info("Auth token headers created.");
            tryingAuthTokenReload = false;
        } catch (HttpStatusCodeException ex) {
            log.info("Auth token loading failed.", ex);
            int statusCode = ex.getStatusCode().value();
            switch (statusCode) {
                case 401:
                    authToken = null;
                    setHttpEntityWithAuthHeader(null);
                    return reloadAuthToken();
                default:
                    throw ex;
            }
        }
        return new AsyncResult<>(authToken);
    }

    /**
     * Retrieves OrderDetail/Amendment with given UID from remote GTN service.
     * <p/>
     * UID will be considered as a OrderDetail/Amendment type and if found the amendment will be returned. If the
     * amendment not available it'll be rechecked for OrderDetail type. If neither types are available an exception is
     * thrown.
     *
     * @param uid OrderDetail/Amendment UID
     *
     * @return OrderDetail/Amendment
     *
     * @throws GTNEntityNotFoundException if the UID does not belong to either OrderDetail or OrderDetail/Amendment
     * @throws HttpStatusCodeException    if other HTTP error occur with the request
     */
    public OrderDetail getOrder(String uid) {
        try {
            URI uri = generateURI(gtnProperties.getApi().getUrlFetchObject(), gtnProperties.getApi().getPoAmendmentType(), uid);
            log.debug("URL: " + uri);
            log.debug("Header: " + httpEntityWithAuthHeader.getHeaders());
            ResponseEntity<OrderDetail> orderDetailResponse = rest.exchange(
                    uri,
                    HttpMethod.GET,
                    httpEntityWithAuthHeader,
                    OrderDetail.class);
            retryCount.set(0);
            return orderDetailResponse.getBody();
        } catch (HttpStatusCodeException ex) {
            int statusCode = ex.getStatusCode().value();
            switch (statusCode) {
                case 401:
                    return retryOnAuthError(ex, () -> getOrder(uid));
                case 404:
                    return retryWithPOType(uid);
                default:
                    throw ex;
            }
        }
    }

}
