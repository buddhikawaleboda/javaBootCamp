package com.virtusa.service;

import com.virtusa.exceptions.EntityNotFoundException;
import com.virtusa.model.HashPassword;
import com.virtusa.model.User;
import com.virtusa.repository.UserRepository;
import com.virtusa.util.SHAPassword;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Service provider for Users
 *
 * @author smpieris
 */
@Service
@Slf4j
public class UserService implements IUserService {

    @Autowired
    private UserRepository userRepository;

    private void cleanUserFields(User user) {
        user.setPassword("");
        user.setSalt("");
    }

    public List<User> cleanUsers(Stream<User> userStream) {
        return userStream.peek(this::cleanUserFields).collect(Collectors.toList());
    }

    @Override
    public List<User> getAllUsers() {
        return cleanUsers(userRepository.findAll().stream());
    }

    @Override
    public boolean createUser(User user) {
        log.debug("checking if user with same username is already available");
        boolean userAlreadyPresent = userRepository.findByUsername(user.getUsername()).isPresent();
        if (!userAlreadyPresent) {
            HashPassword hashedDetails = SHAPassword.hashPassword(user.getPassword());
            user.setPassword(hashedDetails.getHashedPassword());
            user.setSalt(Base64.getEncoder().encodeToString(hashedDetails.getSalt()));
            userRepository.save(user);
            log.debug("no user is present, new user is created");
        } else {
            log.debug("user already available!");
        }
        cleanUserFields(user);
        return userAlreadyPresent;
    }

    @Override
    public void updateUser(User user) {
        User u = userRepository.findById(user.getId()).orElseThrow(() -> new EntityNotFoundException("Cannot find User according to " + user.getId() + " User ID."));
        u.setFirstName(user.getFirstName());
        u.setLastName(user.getLastName());
        u.setEmail(user.getEmail());
        u.setRoles(user.getRoles());
        String pw = user.getPassword();
        log.debug("checking if a new password is set");
        if (pw != null) {
            log.debug("saving new password");
            HashPassword hashedDetails = SHAPassword.hashPassword(pw);
            u.setPassword(hashedDetails.getHashedPassword());
            u.setSalt(Base64.getEncoder().encodeToString(hashedDetails.getSalt()));
        }
        userRepository.flush();
        cleanUserFields(user);
    }

    @Override
    public void deleteUser(int id) {
        try {
            userRepository.delete(id);
        } catch (EmptyResultDataAccessException e) {
            throw new EntityNotFoundException("Cannot match given User Id with any User records", e);
        }
    }
}
