package com.virtusa.service;


import com.virtusa.exceptions.EntityNotFoundException;
import com.virtusa.model.Role;
import com.virtusa.repository.RoleRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Service provider for User Roles.
 *
 * @author smpieris
 */
@Service
@Slf4j
public class RoleService implements IRoleService {

    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private UserService userService;

    @Override
    public List<Role> getAllRoles() {
        return roleRepository.findAll().stream()
                .peek(role -> role.setUsers(userService.cleanUsers(role.getUsers().stream())))
                .collect(Collectors.toList());
    }

    @Override
    public boolean createRole(Role role) {
        log.debug("checking if user role with same type is already available");
        boolean roleAlreadyPresent = roleRepository.findByType(role.getType()).isPresent();
        if (!roleAlreadyPresent) {
            log.debug("no user role is present, new role is created");
            roleRepository.save(role);
        } else {
            log.debug("user role already available!");
        }
        return !roleAlreadyPresent;
    }

    @Override
    public void updateRole(Role role) {
        Role r = roleRepository.findById(role.getId()).orElseThrow(() -> new EntityNotFoundException("Cannot find Role according to " + role.getId() + " Role ID."));
//        r.setType(role.getType());
        r.setDescription(role.getDescription());
        r.setUsers(role.getUsers());
        roleRepository.flush();
    }

    @Override
    public void deleteRole(int id) {
        try {
            roleRepository.delete(id);
        } catch (EmptyResultDataAccessException e) {
            throw new EntityNotFoundException("Cannot match given Role Id with any Role records", e);
        }
    }
}
