package com.virtusa.service;


import com.virtusa.model.User;

import java.util.List;

/**
 * Specification for user management service.
 *
 * @author smpieris
 */
public interface IUserService {

    /**
     * Returns a list of all available Users.
     *
     * @return list of Users
     */
    List<User> getAllUsers();

    /**
     * Creates a User  if  type does not exist.
     *
     * @param user New User to be created
     *
     * @return true if user is created, false if the username exists.
     */
    boolean createUser(User user);

    /**
     * Updates the User with new details.
     *
     * @param user User to be updated.
     */
    void updateUser(User user);

    /**
     * Deletes a User
     *
     * @param id ID of the User to be deleted
     *
     * @throws com.virtusa.exceptions.EntityNotFoundException if a User with given ID is not found.
     */
    void deleteUser(int id);
}
