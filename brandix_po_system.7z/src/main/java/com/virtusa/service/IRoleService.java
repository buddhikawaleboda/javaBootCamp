package com.virtusa.service;


import com.virtusa.model.Role;

import java.util.List;

/**
 * Specification for user role management service.
 *
 * @author smpieris
 */
public interface IRoleService {

    /**
     * Returns a list of all available User Roles.
     *
     * @return list of User Roles
     */
    List<Role> getAllRoles();

    /**
     * Creates a User Role if role type does not exist.
     *
     * @param role New User Role to be created
     *
     * @return true if role is created, false if the role type exists.
     */
    boolean createRole(Role role);

    /**
     * Updates the User Role with new details.
     *
     * @param role User Role to be updated.
     */
    void updateRole(Role role);

    /**
     * Deletes a User Role
     *
     * @param id Role ID of the Role to be deleted
     *
     * @throws com.virtusa.exceptions.EntityNotFoundException if a User Role with given ID is not found.
     */
    void deleteRole(int id);

}
