package com.virtusa.service;

import com.virtusa.exceptions.EntityNotFoundException;
import com.virtusa.model.OrderDetail;
import com.virtusa.model.PurchaseOrder;
import com.virtusa.model.PurchaseOrderEdit;
import com.virtusa.repository.ILocalPurchaseOrderRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Service provider for local purchase orders.
 *
 * @author ddissnayake
 */
@Service
@Slf4j
public class LocalPurchaseOrderService implements ILocalPurchaseOrderService {

    @Autowired
    private GTNService gtnService;
    @Autowired
    private ILocalPurchaseOrderRepository localPurchaseOrderRepository;

    private PurchaseOrder applyEdits(PurchaseOrder purchaseOrder) {
        purchaseOrder.getPurchaseOrderEdits().forEach(edit -> {
            String fieldName = WordUtils.uncapitalize("orderDetail." + edit.getFieldName(), '_', '.');
            try {
                PropertyUtils.setNestedProperty(purchaseOrder, fieldName, edit.getValue());
            } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                log.error("Error setting edit values", e);
            }
        });
        return purchaseOrder;
    }

    private List<PurchaseOrderEdit> addNewEdits(Map<String, String> editsMap, PurchaseOrder purchaseOrder, List<PurchaseOrderEdit> purchaseOrderEdits) {
        editsMap.keySet().removeAll(
                purchaseOrder.getPurchaseOrderEdits().stream()
                        .map(PurchaseOrderEdit::getFieldName)
                        .collect(Collectors.toList())
        );
        purchaseOrderEdits.addAll(
                editsMap.entrySet().stream()
                        .map(entry -> new PurchaseOrderEdit(purchaseOrder, entry.getKey(), entry.getValue()))
                        .collect(Collectors.toList())
        );
        return purchaseOrderEdits;
    }

    private void setEditValue(PurchaseOrderEdit purchaseOrderEdit, Map<String, String> editsMap) {
        String value = editsMap.get(purchaseOrderEdit.getFieldName());
        if (value != null) {
            purchaseOrderEdit.setValue(value);
        }
    }

    @Override
    public boolean persist(String uid) {
        log.debug("Persisting PO: " + uid);
        OrderDetail order = gtnService.getOrder(uid);
        log.debug("PO retrieved via GTNService");
        PurchaseOrder purchaseOrder = localPurchaseOrderRepository.findByOrderUid(uid).orElse(new PurchaseOrder());
        purchaseOrder.setOrderDetail(order);
        boolean newlyCreated = false;
        if (purchaseOrder.getId() == null) {
            log.info("Local PO not found, new PO created");
            newlyCreated = true;
        } else {
            log.info("Local PO found, will be updated");
        }
        localPurchaseOrderRepository.save(purchaseOrder);
        log.debug("PO persisted.");
        return newlyCreated;
    }

    @Override
    public PurchaseOrder get(String uid) {
        return localPurchaseOrderRepository.findByOrderUid(uid).map(this::applyEdits).orElseThrow(() -> new EntityNotFoundException("OrderDetail#" + uid));
    }

    @Override
    public List<PurchaseOrder> list() {
        return localPurchaseOrderRepository.findAll();
    }

    @Override
    public void save(String uid, Map<String, String> editsMap) {
        PurchaseOrder purchaseOrder = localPurchaseOrderRepository.findByOrderUid(uid).orElseThrow(() -> new EntityNotFoundException("OrderDetail#" + uid));
        List<PurchaseOrderEdit> purchaseOrderEdits = purchaseOrder.getPurchaseOrderEdits().stream()
                .peek(poEdit -> setEditValue(poEdit, editsMap))
                .collect(Collectors.collectingAndThen(Collectors.toList(), list -> addNewEdits(editsMap, purchaseOrder, list)));
        purchaseOrder.setPurchaseOrderEdits(purchaseOrderEdits);
        localPurchaseOrderRepository.flush();
    }
}
