package com.virtusa.service;

import com.virtusa.model.PurchaseOrder;

import java.util.List;
import java.util.Map;

/**
 * Specification for local purchase order management service
 *
 * @author ddissnayake
 */
public interface ILocalPurchaseOrderService {

    /**
     * Gets the OrderDetail/Amendment from the remote service and persists it locally.
     * <p/>
     * If the local entity for given UID is already available, it will be updated and false will be returned.
     *
     * @param uid UID of the OrderDetail/Amendment
     *
     * @return true if a new entity created locally
     */
    boolean persist(String uid);

    /**
     * Returns the local purchase order with given UID
     *
     * @param uid UID of the OrderDetail
     *
     * @return purchase order
     *
     * @throws com.virtusa.exceptions.EntityNotFoundException if the purchase order with the given UID is not found
     *                                                        locally
     */
    PurchaseOrder get(String uid);

    /**
     * Returns the all locally available purchase orders.
     *
     * @return list of purchase orders
     */
    List<PurchaseOrder> list();

    /**
     * Save edits to OrderDetail.
     *
     * @param uid      Order UID
     * @param editsMap Map of changes in format of fieldName:newValue
     */
    void save(String uid, Map<String, String> editsMap);
}
