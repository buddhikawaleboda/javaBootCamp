package com.virtusa.controller;


import com.virtusa.model.User;
import com.virtusa.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for Users.
 *
 * @author smpieris
 */
@RestController
@RequestMapping("user")
@Slf4j
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("create")
    ResponseEntity<Void> createUser(@RequestBody User user) {
        boolean userAlreadyPresent = userService.createUser(user);
        if (userAlreadyPresent) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        log.info("User created Successfully");
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @GetMapping("users")
    public ResponseEntity<List<User>> getAllEmployees() {
        List<User> list = userService.getAllUsers();
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @PutMapping("update")
    public ResponseEntity<User> updateUser(@RequestBody User user) {
        userService.updateUser(user);
        log.info("User updated Successfully");
        return new ResponseEntity<>(user, HttpStatus.OK);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable("id") int id) {
        userService.deleteUser(id);
        log.info("The user referencing by id number " + id + " was deleted........");
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
