package com.virtusa.controller;


import com.virtusa.model.Role;
import com.virtusa.service.RoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for User Roles.
 *
 * @author smpieris
 */
@RestController
@RequestMapping("role")
@Slf4j
public class RoleController {

    @Autowired
    private RoleService roleService;

    @GetMapping("roles")
    public ResponseEntity<List<Role>> getAllEmployees() {
        List<Role> list = roleService.getAllRoles();
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @PostMapping("create")
    ResponseEntity<?> createRole(@RequestBody Role role) {
        boolean roleCreated = roleService.createRole(role);
        if (!roleCreated) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        log.info("User Role created Successfully");
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("update")
    public ResponseEntity<Role> updateRole(@RequestBody Role role) {
        roleService.updateRole(role);
        log.info("User Role updated Successfully");
        return new ResponseEntity<>(role, HttpStatus.OK);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteRole(@PathVariable("id") String id) {
        roleService.deleteRole(Integer.parseInt(id));
        log.info("User Role deleted Successfully");
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
