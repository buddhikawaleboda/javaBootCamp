package com.virtusa.controller;

import com.virtusa.exceptions.GTNNotInitializedException;
import com.virtusa.model.OrderDetail;
import com.virtusa.model.PurchaseOrder;
import com.virtusa.service.GTNService;
import com.virtusa.service.ILocalPurchaseOrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.net.URI;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * REST controller for Purchase Orders.
 *
 * @author ddissnayake
 */
@RestController
@RequestMapping("po")
@Slf4j
public class PurchaseOrderController {

    @Autowired
    private GTNService gtnService;
    @Autowired
    private ILocalPurchaseOrderService localPurchaseOrderService;

    @PostConstruct
    void initGTNService() {
        gtnService.reloadAuthToken();
    }

    @GetMapping(path = "{uid}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    ResponseEntity<OrderDetail> getOrder(@PathVariable String uid) {
        log.debug("request for get(" + uid + ")");
        if (gtnService.isInitialized()) {
            return ResponseEntity.ok(gtnService.getOrder(uid));
        } else {
            log.warn("GTNService not initialized yet.");
            throw new GTNNotInitializedException();
        }
    }

    @PostMapping("{uid}")
    ResponseEntity<?> persistOrder(@PathVariable String uid) {
        log.debug("request for persistOrder(" + uid + ")");
        if (gtnService.isInitialized()) {
            boolean newlyCreated = localPurchaseOrderService.persist(uid);
            if (newlyCreated) {
                return ResponseEntity.created(URI.create("po/local/" + uid)).build();
            } else {
                return ResponseEntity.accepted().build();
            }
        } else {
            log.warn("GTNService not initialized yet.");
            throw new GTNNotInitializedException();
        }
    }

    @GetMapping(path = "local/list", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    ResponseEntity<Set<OrderDetail>> listLocalOrders() {
        log.debug("request for listLocalOrders()");
        return ResponseEntity.ok(localPurchaseOrderService.list().stream().map(PurchaseOrder::getOrderDetail).collect(Collectors.toSet()));
    }

    @GetMapping(path = "local/{uid}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    ResponseEntity<OrderDetail> getLocalOrder(@PathVariable String uid) {
        log.debug("request for getLocalOrder(" + uid + ")");
        return ResponseEntity.ok(localPurchaseOrderService.get(uid).getOrderDetail());
    }

    @PutMapping(value = "local/{uid}", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    ResponseEntity<?> editLocalOrders(@PathVariable String uid, @RequestBody Map<String, String> editsMap) {
        log.debug("request for editLocalOrders()");
        localPurchaseOrderService.save(uid, editsMap);
        return ResponseEntity.accepted().build();
    }

}
