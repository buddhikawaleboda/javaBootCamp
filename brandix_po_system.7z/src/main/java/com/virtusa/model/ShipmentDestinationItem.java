package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class ShipmentDestinationItem {

    @JsonProperty("partyRoleCode")
    private String partyRoleCode;

    @JsonProperty("address")
    private Address address;

    @JsonProperty("name")
    private String name;

    public String getPartyRoleCode() {
        return partyRoleCode;
    }

    public void setPartyRoleCode(String partyRoleCode) {
        this.partyRoleCode = partyRoleCode;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return
                "ShipmentDestinationItem{" +
                        "partyRoleCode = '" + partyRoleCode + '\'' +
                        ",address = '" + address + '\'' +
                        ",name = '" + name + '\'' +
                        "}";
    }
}