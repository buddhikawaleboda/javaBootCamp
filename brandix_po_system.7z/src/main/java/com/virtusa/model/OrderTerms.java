package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class OrderTerms {

    @JsonProperty("incotermCode")
    private String incotermCode;

    @JsonProperty("incotermLocationCode")
    private String incotermLocationCode;

    @JsonProperty("isPartialShipmentAllowed")
    private String isPartialShipmentAllowed;

    @JsonProperty("freightPaymentCode")
    private String freightPaymentCode;

    @JsonProperty("isTransShipmentAllowed")
    private String isTransShipmentAllowed;

    @JsonProperty("orderDate")
    private OrderDate orderDate;

    @JsonProperty("currencyCode")
    private String currencyCode;

    public String getIncotermCode() {
        return incotermCode;
    }

    public void setIncotermCode(String incotermCode) {
        this.incotermCode = incotermCode;
    }

    public String getIncotermLocationCode() {
        return incotermLocationCode;
    }

    public void setIncotermLocationCode(String incotermLocationCode) {
        this.incotermLocationCode = incotermLocationCode;
    }

    public String getIsPartialShipmentAllowed() {
        return isPartialShipmentAllowed;
    }

    public void setIsPartialShipmentAllowed(String isPartialShipmentAllowed) {
        this.isPartialShipmentAllowed = isPartialShipmentAllowed;
    }

    public String getFreightPaymentCode() {
        return freightPaymentCode;
    }

    public void setFreightPaymentCode(String freightPaymentCode) {
        this.freightPaymentCode = freightPaymentCode;
    }

    public String getIsTransShipmentAllowed() {
        return isTransShipmentAllowed;
    }

    public void setIsTransShipmentAllowed(String isTransShipmentAllowed) {
        this.isTransShipmentAllowed = isTransShipmentAllowed;
    }

    public OrderDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(OrderDate orderDate) {
        this.orderDate = orderDate;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    @Override
    public String toString() {
        return
                "OrderTerms{" +
                        "incotermCode = '" + incotermCode + '\'' +
                        ",incotermLocationCode = '" + incotermLocationCode + '\'' +
                        ",isPartialShipmentAllowed = '" + isPartialShipmentAllowed + '\'' +
                        ",freightPaymentCode = '" + freightPaymentCode + '\'' +
                        ",isTransShipmentAllowed = '" + isTransShipmentAllowed + '\'' +
                        ",orderDate = '" + orderDate + '\'' +
                        ",currencyCode = '" + currencyCode + '\'' +
                        "}";
    }
}