package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class ConsigneeItem {

    @JsonProperty("partyRoleCode")
    private String partyRoleCode;

    @JsonProperty("address")
    private Address address;

    @JsonProperty("contact")
    private Contact contact;

    @JsonProperty("name")
    private String name;

    @JsonProperty("memberId")
    private String memberId;

    public String getPartyRoleCode() {
        return partyRoleCode;
    }

    public void setPartyRoleCode(String partyRoleCode) {
        this.partyRoleCode = partyRoleCode;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    @Override
    public String toString() {
        return
                "ConsigneeItem{" +
                        "partyRoleCode = '" + partyRoleCode + '\'' +
                        ",address = '" + address + '\'' +
                        ",contact = '" + contact + '\'' +
                        ",name = '" + name + '\'' +
                        ",memberId = '" + memberId + '\'' +
                        "}";
    }
}