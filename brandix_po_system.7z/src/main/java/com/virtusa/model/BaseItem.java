package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class BaseItem {

    @JsonProperty("reference")
    private Reference reference;

    @JsonProperty("quantity")
    private String quantity;

    @JsonProperty("itemTypeCode")
    private String itemTypeCode;

    @JsonProperty("itemIdentifier")
    private ItemIdentifier itemIdentifier;

    @JsonProperty("unitOfMeasureCode")
    private String unitOfMeasureCode;

    @JsonProperty("party")
    private List<PartyItem> party;

    @JsonProperty("itemUid")
    private String itemUid;

    public Reference getReference() {
        return reference;
    }

    public void setReference(Reference reference) {
        this.reference = reference;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getItemTypeCode() {
        return itemTypeCode;
    }

    public void setItemTypeCode(String itemTypeCode) {
        this.itemTypeCode = itemTypeCode;
    }

    public ItemIdentifier getItemIdentifier() {
        return itemIdentifier;
    }

    public void setItemIdentifier(ItemIdentifier itemIdentifier) {
        this.itemIdentifier = itemIdentifier;
    }

    public String getUnitOfMeasureCode() {
        return unitOfMeasureCode;
    }

    public void setUnitOfMeasureCode(String unitOfMeasureCode) {
        this.unitOfMeasureCode = unitOfMeasureCode;
    }

    public List<PartyItem> getParty() {
        return party;
    }

    public void setParty(List<PartyItem> party) {
        this.party = party;
    }

    public String getItemUid() {
        return itemUid;
    }

    public void setItemUid(String itemUid) {
        this.itemUid = itemUid;
    }

    @Override
    public String toString() {
        return
                "BaseItem{" +
                        "reference = '" + reference + '\'' +
                        ",quantity = '" + quantity + '\'' +
                        ",itemTypeCode = '" + itemTypeCode + '\'' +
                        ",itemIdentifier = '" + itemIdentifier + '\'' +
                        ",unitOfMeasureCode = '" + unitOfMeasureCode + '\'' +
                        ",party = '" + party + '\'' +
                        ",itemUid = '" + itemUid + '\'' +
                        "}";
    }
}