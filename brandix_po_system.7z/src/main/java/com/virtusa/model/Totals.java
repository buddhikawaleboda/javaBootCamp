package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Totals {

    @JsonProperty("totalMerchandiseAmount")
    private String totalMerchandiseAmount;

    @JsonProperty("totalQuantity")
    private String totalQuantity;

    @JsonProperty("totalDocumentAmount")
    private String totalDocumentAmount;

    public String getTotalMerchandiseAmount() {
        return totalMerchandiseAmount;
    }

    public void setTotalMerchandiseAmount(String totalMerchandiseAmount) {
        this.totalMerchandiseAmount = totalMerchandiseAmount;
    }

    public String getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(String totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public String getTotalDocumentAmount() {
        return totalDocumentAmount;
    }

    public void setTotalDocumentAmount(String totalDocumentAmount) {
        this.totalDocumentAmount = totalDocumentAmount;
    }

    @Override
    public String toString() {
        return
                "Totals{" +
                        "totalMerchandiseAmount = '" + totalMerchandiseAmount + '\'' +
                        ",totalQuantity = '" + totalQuantity + '\'' +
                        ",totalDocumentAmount = '" + totalDocumentAmount + '\'' +
                        "}";
    }
}