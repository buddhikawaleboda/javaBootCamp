package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class OrderDetail {

    @JsonProperty("redirectUrl")
    private String redirectUrl;

    @JsonProperty("orderUid")
    private String orderUid;

    @JsonProperty("changeDescription")
    private List<ChangeDescriptionItem> changeDescription;

    @JsonProperty("orderItem")
    private List<OrderItemItem> orderItem;

    @JsonProperty("orderStatusCode")
    private String orderStatusCode;

    @JsonProperty("orderFunctionCode")
    private String orderFunctionCode;

    @JsonProperty("totals")
    private Totals totals;

    @JsonProperty("__metadata")
    private Metadata metadata;

    @JsonProperty("poNumber")
    private String poNumber;

    @JsonProperty("orderTerms")
    private OrderTerms orderTerms;

    @JsonProperty("party")
    private Party party;

    @JsonProperty("subMessageId")
    private String subMessageId;

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public String getOrderUid() {
        return orderUid;
    }

    public void setOrderUid(String orderUid) {
        this.orderUid = orderUid;
    }

    public List<ChangeDescriptionItem> getChangeDescription() {
        return changeDescription;
    }

    public void setChangeDescription(List<ChangeDescriptionItem> changeDescription) {
        this.changeDescription = changeDescription;
    }

    public List<OrderItemItem> getOrderItem() {
        return orderItem;
    }

    public void setOrderItem(List<OrderItemItem> orderItem) {
        this.orderItem = orderItem;
    }

    public String getOrderStatusCode() {
        return orderStatusCode;
    }

    public void setOrderStatusCode(String orderStatusCode) {
        this.orderStatusCode = orderStatusCode;
    }

    public String getOrderFunctionCode() {
        return orderFunctionCode;
    }

    public void setOrderFunctionCode(String orderFunctionCode) {
        this.orderFunctionCode = orderFunctionCode;
    }

    public Totals getTotals() {
        return totals;
    }

    public void setTotals(Totals totals) {
        this.totals = totals;
    }

    public Metadata getMetadata() {
        return metadata;
    }

    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public OrderTerms getOrderTerms() {
        return orderTerms;
    }

    public void setOrderTerms(OrderTerms orderTerms) {
        this.orderTerms = orderTerms;
    }

    public Party getParty() {
        return party;
    }

    public void setParty(Party party) {
        this.party = party;
    }

    public String getSubMessageId() {
        return subMessageId;
    }

    public void setSubMessageId(String subMessageId) {
        this.subMessageId = subMessageId;
    }

    @Override
    public String toString() {
        return
                "OrderDetail{" +
                        "redirectUrl = '" + redirectUrl + '\'' +
                        ",orderUid = '" + orderUid + '\'' +
                        ",changeDescription = '" + changeDescription + '\'' +
                        ",orderItem = '" + orderItem + '\'' +
                        ",orderStatusCode = '" + orderStatusCode + '\'' +
                        ",orderFunctionCode = '" + orderFunctionCode + '\'' +
                        ",totals = '" + totals + '\'' +
                        ",__metadata = '" + metadata + '\'' +
                        ",poNumber = '" + poNumber + '\'' +
                        ",orderTerms = '" + orderTerms + '\'' +
                        ",party = '" + party + '\'' +
                        ",subMessageId = '" + subMessageId + '\'' +
                        "}";
    }
}