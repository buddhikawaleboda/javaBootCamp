package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class InitResponse {

    @JsonProperty("apiVersion")
    private int apiVersion;

    @JsonProperty("objectType")
    private List<String> objectType;

    public int getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(int apiVersion) {
        this.apiVersion = apiVersion;
    }

    public List<String> getObjectType() {
        return objectType;
    }

    public void setObjectType(List<String> objectType) {
        this.objectType = objectType;
    }

    @Override
    public String toString() {
        return
                "InitResponse{" +
                        "apiVersion = '" + apiVersion + '\'' +
                        ",objectType = '" + objectType + '\'' +
                        "}";
    }
}