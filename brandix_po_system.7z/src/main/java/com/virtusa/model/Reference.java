package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Reference {

    @JsonProperty("ItemStatus")
    private String itemStatus;

    public String getItemStatus() {
        return itemStatus;
    }

    public void setItemStatus(String itemStatus) {
        this.itemStatus = itemStatus;
    }

    @Override
    public String toString() {
        return
                "Reference{" +
                        "itemStatus = '" + itemStatus + '\'' +
                        "}";
    }
}