package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Address {

    @JsonProperty("addressUid")
    private String addressUid;

    @JsonProperty("stateOrProvince")
    private String stateOrProvince;

    @JsonProperty("city")
    private String city;

    @JsonProperty("countryCode")
    private String countryCode;

    @JsonProperty("addressLine1")
    private String addressLine1;

    @JsonProperty("postalCodeNumber")
    private String postalCodeNumber;

    public String getAddressUid() {
        return addressUid;
    }

    public void setAddressUid(String addressUid) {
        this.addressUid = addressUid;
    }

    public String getStateOrProvince() {
        return stateOrProvince;
    }

    public void setStateOrProvince(String stateOrProvince) {
        this.stateOrProvince = stateOrProvince;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getPostalCodeNumber() {
        return postalCodeNumber;
    }

    public void setPostalCodeNumber(String postalCodeNumber) {
        this.postalCodeNumber = postalCodeNumber;
    }

    @Override
    public String toString() {
        return
                "Address{" +
                        "addressUid = '" + addressUid + '\'' +
                        ",stateOrProvince = '" + stateOrProvince + '\'' +
                        ",city = '" + city + '\'' +
                        ",countryCode = '" + countryCode + '\'' +
                        ",addressLine1 = '" + addressLine1 + '\'' +
                        ",postalCodeNumber = '" + postalCodeNumber + '\'' +
                        "}";
    }
}