package com.virtusa.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class HashPassword {

    private String hashedPassword;
    private byte[] salt;

}
