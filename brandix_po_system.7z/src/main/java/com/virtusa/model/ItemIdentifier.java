package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class ItemIdentifier {

    @JsonProperty("ItemSequenceNumber")
    private String itemSequenceNumber;

    @JsonProperty("BuyerNumber")
    private String buyerNumber;

    @JsonProperty("ShortDescription")
    private String shortDescription;

    public String getItemSequenceNumber() {
        return itemSequenceNumber;
    }

    public void setItemSequenceNumber(String itemSequenceNumber) {
        this.itemSequenceNumber = itemSequenceNumber;
    }

    public String getBuyerNumber() {
        return buyerNumber;
    }

    public void setBuyerNumber(String buyerNumber) {
        this.buyerNumber = buyerNumber;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    @Override
    public String toString() {
        return
                "ItemIdentifier{" +
                        "itemSequenceNumber = '" + itemSequenceNumber + '\'' +
                        ",buyerNumber = '" + buyerNumber + '\'' +
                        ",shortDescription = '" + shortDescription + '\'' +
                        "}";
    }
}