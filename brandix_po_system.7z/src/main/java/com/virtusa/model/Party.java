package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class Party {

    @JsonProperty("Consignee")
    private List<ConsigneeItem> consignee;

    @JsonProperty("ShipmentDestination")
    private List<ShipmentDestinationItem> shipmentDestination;

    @JsonProperty("NotifyParty1")
    private List<NotifyParty1Item> notifyParty1;

    @JsonProperty("Buyer")
    private List<BuyerItem> buyer;

    @JsonProperty("Seller")
    private List<SellerItem> seller;

    @JsonProperty("FinalDestination")
    private List<FinalDestinationItem> finalDestination;

    public List<ConsigneeItem> getConsignee() {
        return consignee;
    }

    public void setConsignee(List<ConsigneeItem> consignee) {
        this.consignee = consignee;
    }

    public List<ShipmentDestinationItem> getShipmentDestination() {
        return shipmentDestination;
    }

    public void setShipmentDestination(List<ShipmentDestinationItem> shipmentDestination) {
        this.shipmentDestination = shipmentDestination;
    }

    public List<NotifyParty1Item> getNotifyParty1() {
        return notifyParty1;
    }

    public void setNotifyParty1(List<NotifyParty1Item> notifyParty1) {
        this.notifyParty1 = notifyParty1;
    }

    public List<BuyerItem> getBuyer() {
        return buyer;
    }

    public void setBuyer(List<BuyerItem> buyer) {
        this.buyer = buyer;
    }

    public List<SellerItem> getSeller() {
        return seller;
    }

    public void setSeller(List<SellerItem> seller) {
        this.seller = seller;
    }

    public List<FinalDestinationItem> getFinalDestination() {
        return finalDestination;
    }

    public void setFinalDestination(List<FinalDestinationItem> finalDestination) {
        this.finalDestination = finalDestination;
    }

    @Override
    public String toString() {
        return
                "Party{" +
                        "consignee = '" + consignee + '\'' +
                        ",shipmentDestination = '" + shipmentDestination + '\'' +
                        ",notifyParty1 = '" + notifyParty1 + '\'' +
                        ",buyer = '" + buyer + '\'' +
                        ",seller = '" + seller + '\'' +
                        ",finalDestination = '" + finalDestination + '\'' +
                        "}";
    }
}