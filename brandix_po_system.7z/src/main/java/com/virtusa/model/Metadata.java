package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Metadata {

    @JsonProperty("uid")
    private String uid;

    @JsonProperty("apiVersion")
    private String apiVersion;

    @JsonProperty("redirectUrl")
    private String redirectUrl;

    @JsonProperty("fingerprint")
    private String fingerprint;

    @JsonProperty("self")
    private String self;

    @JsonProperty("type")
    private String type;

    @JsonProperty("createTimestamp")
    private String createTimestamp;

    @JsonProperty("modifyTimestamp")
    private String modifyTimestamp;

    @JsonProperty("status")
    private String status;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public String getFingerprint() {
        return fingerprint;
    }

    public void setFingerprint(String fingerprint) {
        this.fingerprint = fingerprint;
    }

    public String getSelf() {
        return self;
    }

    public void setSelf(String self) {
        this.self = self;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(String createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public String getModifyTimestamp() {
        return modifyTimestamp;
    }

    public void setModifyTimestamp(String modifyTimestamp) {
        this.modifyTimestamp = modifyTimestamp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return
                "Metadata{" +
                        "uid = '" + uid + '\'' +
                        ",apiVersion = '" + apiVersion + '\'' +
                        ",redirectUrl = '" + redirectUrl + '\'' +
                        ",fingerprint = '" + fingerprint + '\'' +
                        ",self = '" + self + '\'' +
                        ",type = '" + type + '\'' +
                        ",createTimestamp = '" + createTimestamp + '\'' +
                        ",modifyTimestamp = '" + modifyTimestamp + '\'' +
                        ",status = '" + status + '\'' +
                        "}";
    }
}