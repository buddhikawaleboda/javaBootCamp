package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class FinalDestinationItem {

    @JsonProperty("partyRoleCode")
    private String partyRoleCode;

    @JsonProperty("address")
    private Address address;

    @JsonProperty("contact")
    private Contact contact;

    @JsonProperty("name")
    private String name;

    @JsonProperty("partyUid")
    private String partyUid;

    public String getPartyRoleCode() {
        return partyRoleCode;
    }

    public void setPartyRoleCode(String partyRoleCode) {
        this.partyRoleCode = partyRoleCode;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPartyUid() {
        return partyUid;
    }

    public void setPartyUid(String partyUid) {
        this.partyUid = partyUid;
    }

    @Override
    public String toString() {
        return
                "FinalDestinationItem{" +
                        "partyRoleCode = '" + partyRoleCode + '\'' +
                        ",address = '" + address + '\'' +
                        ",contact = '" + contact + '\'' +
                        ",name = '" + name + '\'' +
                        ",partyUid = '" + partyUid + '\'' +
                        "}";
    }
}