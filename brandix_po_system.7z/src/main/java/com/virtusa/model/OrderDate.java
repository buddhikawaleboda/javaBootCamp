package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class OrderDate {

    @JsonProperty("Issue")
    private String issue;

    @JsonProperty("Latest")
    private String latest;

    @JsonProperty("Earliest")
    private String earliest;

    @JsonProperty("CancelAfter")
    private String cancelAfter;

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public String getLatest() {
        return latest;
    }

    public void setLatest(String latest) {
        this.latest = latest;
    }

    public String getEarliest() {
        return earliest;
    }

    public void setEarliest(String earliest) {
        this.earliest = earliest;
    }

    public String getCancelAfter() {
        return cancelAfter;
    }

    public void setCancelAfter(String cancelAfter) {
        this.cancelAfter = cancelAfter;
    }

    @Override
    public String toString() {
        return
                "OrderDate{" +
                        "issue = '" + issue + '\'' +
                        ",latest = '" + latest + '\'' +
                        ",earliest = '" + earliest + '\'' +
                        ",cancelAfter = '" + cancelAfter + '\'' +
                        "}";
    }
}