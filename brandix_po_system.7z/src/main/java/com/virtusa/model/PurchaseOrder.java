package com.virtusa.model;

import com.virtusa.util.OrderDetailConverter;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
public class PurchaseOrder extends BaseModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Convert(converter = OrderDetailConverter.class)
    private OrderDetail orderDetail;
    @Column(insertable = false, updatable = false)
    private String orderUid = null;
    private String status;
    @OneToMany(mappedBy = "purchaseOrder", cascade = CascadeType.MERGE)
    private List<PurchaseOrderEdit> purchaseOrderEdits;

}
