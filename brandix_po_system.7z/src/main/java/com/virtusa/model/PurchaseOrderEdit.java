package com.virtusa.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
public class PurchaseOrderEdit extends BaseModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String fieldName;
    @ManyToOne
    private PurchaseOrder purchaseOrder;
    @Setter
    private String value;

    public PurchaseOrderEdit(PurchaseOrder purchaseOrder, String fieldName, String value) {
        this.fieldName = fieldName;
        this.purchaseOrder = purchaseOrder;
        this.value = value;
    }
}
