package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class OrderItemItem {

    @JsonProperty("itemPrice")
    private ItemPrice itemPrice;

    @JsonProperty("baseItem")
    private BaseItem baseItem;

    @JsonProperty("itemKey")
    private String itemKey;

    public ItemPrice getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(ItemPrice itemPrice) {
        this.itemPrice = itemPrice;
    }

    public BaseItem getBaseItem() {
        return baseItem;
    }

    public void setBaseItem(BaseItem baseItem) {
        this.baseItem = baseItem;
    }

    public String getItemKey() {
        return itemKey;
    }

    public void setItemKey(String itemKey) {
        this.itemKey = itemKey;
    }

    @Override
    public String toString() {
        return
                "OrderItemItem{" +
                        "itemPrice = '" + itemPrice + '\'' +
                        ",baseItem = '" + baseItem + '\'' +
                        ",itemKey = '" + itemKey + '\'' +
                        "}";
    }
}