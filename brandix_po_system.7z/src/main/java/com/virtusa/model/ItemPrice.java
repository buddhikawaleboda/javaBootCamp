package com.virtusa.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class ItemPrice {

    @JsonProperty("totalPrice")
    private String totalPrice;

    @JsonProperty("pricePerUnit")
    private String pricePerUnit;

    public String getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getPricePerUnit() {
        return pricePerUnit;
    }

    public void setPricePerUnit(String pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
    }

    @Override
    public String toString() {
        return
                "ItemPrice{" +
                        "totalPrice = '" + totalPrice + '\'' +
                        ",pricePerUnit = '" + pricePerUnit + '\'' +
                        "}";
    }
}