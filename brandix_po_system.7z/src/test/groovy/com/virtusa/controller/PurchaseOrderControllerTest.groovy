package com.virtusa.controller

import spock.lang.Shared
import spock.lang.Specification

class PurchaseOrderControllerTest extends Specification {

    private static class Props {
        def host_and_port = "localhost:3306"
        def dbname = "test_brandix_po"
        def dbuser = "root"
        def dbpassword = "root"
    }

    private final static ORDER_UID = '98783190'
    private final static props = new Props()
    private final static OK = 200
    private final static CREATED = 201
    private final static ACCEPTED = 202

    @Shared
    def db = [url : "jdbc:mysql://$props.host_and_port/$props.dbname?useUnicode=true&characterEncoding=UTF-8",
              user: props.dbuser, password: props.dbpassword, driver: 'com.mysql.jdbc.Driver']
//
//    def "Test persist PO"() {
//        given:
//        def client = new RESTClient("http://localhost:8080/po/")
//        client.setHeaders(Accept: 'application/json')
//
//        when:
//        def response = client.post(path: ORDER_UID)
//
//        then:
//        assert response.status == CREATED || ACCEPTED
//    }
//
//    def "Test list local POs"() {
//        given:
//        def client = new HTTPBuilder("http://localhost:8080/po/")
//        when:
//        def response = client.get(path: 'local/list')
//        then:
//        assert response.status == OK
//    }
//
//    def "Test get local PO"() {
//        when:
//        def response = client.get(path: "local/$ORDER_UID")
//        def sql = Sql.newInstance(db.url, db.user, db.password, db.driver)
//        def po = sql.firstRow("SELECT * FROM purchase_order WHERE order_uid = $ORDER_UID")
//
//        then:
//
//
//        assert JSONAssert.assertJsonEquals(po["order_detail"] as String, JsonOutput.toJson(response.data))
//        sql.close()
//    }


}
