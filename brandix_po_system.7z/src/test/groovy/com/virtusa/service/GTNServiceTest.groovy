package com.virtusa.service

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.test.context.ContextConfiguration
import spock.lang.Shared
import spock.lang.Specification

/**
 * Created by delegate on 9/18/17.
 */
@ContextConfiguration
@SpringBootTest
class GTNServiceTest extends Specification {

    @Autowired
    GTNService gtnService
    @Shared
    def authTokenHeader = new HttpHeaders() {
        {
            set("Authorization", "InvalidAuthToken")
        }
    }

    def "On Auth Error Retry Mechanism"() {
        setup:
        gtnService.setHttpEntityWithAuthHeader new HttpEntity<>(authTokenHeader)

        when:
        gtnService.getOrder "98783190"

        then:
        print "Test done"
    }
}
