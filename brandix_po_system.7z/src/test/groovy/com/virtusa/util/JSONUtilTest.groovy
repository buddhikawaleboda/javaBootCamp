package com.virtusa.util

import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString
import spock.lang.Shared
import spock.lang.Specification

/**
 * Created by delegate on 9/15/17.
 */
class JSONUtilTest extends Specification {

    @Shared
    def jsonString = "{\"id\":1,\"name\":\"Person one\",\"address\":{\"no\":\"No 24\",\"line1\":\"Colombo Rd\",\"line2\":null,\"city\":{\"zip\":20000,\"name\":\"Kandy\"}},\"salary\":20000}"
    @Shared
    def city = new City(20000, "Kandy")
    @Shared
    def address = new Address("No 24", "Colombo Rd", null, city)
    @Shared
    def person = new Person(1, "Person one", address, BigDecimal.valueOf(20000))

    @ToString
    @EqualsAndHashCode
    static class City {
        int zip
        String name

        City() {
        }

        City(int zip, String name) {
            this.zip = zip
            this.name = name
        }
    }

    @ToString
    @EqualsAndHashCode
    static class Address {
        String no
        String line1
        String line2
        City city

        Address() {
        }

        Address(String no, String line1, String line2, City city) {
            this.no = no
            this.line1 = line1
            this.line2 = line2
            this.city = city
        }
    }

    @ToString
    @EqualsAndHashCode
    static class Person {
        int id
        String name
        Address address
        BigDecimal salary

        Person() {
        }

        Person(int id, String name, Address address, BigDecimal salary) {
            this.id = id
            this.name = name
            this.address = address
            this.salary = salary
        }


    }

    def "ObjectToJson"() {
        when:
        def json = JSONUtil.toJson person

        then:
        json.equals jsonString
    }

    def "JsonToObject"() {
        when:
        def person = JSONUtil.fromJson Person.class, jsonString

        then:
        person.equals this.person
    }
}
