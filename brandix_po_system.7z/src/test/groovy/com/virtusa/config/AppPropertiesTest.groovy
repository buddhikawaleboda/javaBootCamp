package com.virtusa.config

import com.virtusa.properties.AppProperties
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

/**
 * Created by delegate on 9/18/17.
 */

@ContextConfiguration
@SpringBootTest
class AppPropertiesTest extends Specification {

    @Autowired
    AppProperties appProperties

    def "Check Property Loading"() {
        setup:
        def basePackage = "com.virtusa"
        def fetchURL = "%s/{type}/{uid}?datakey=%s"

        expect:
        appProperties.basePackage == basePackage
        appProperties.swaggerApiInfo.title != null
        appProperties.gtnProperties.api.urlFetchObject == fetchURL
    }
}
