package com.virtusa

import groovyx.net.http.ContentType
import groovyx.net.http.RESTClient
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Stepwise

@Stepwise
class UserRestClientSpec extends Specification {

    static OK = 200
    static CREATED = 201
    static CONFLICT = 409
    static NO_CONTENT = 204
    static NOT_FOUND = 404

    static VALID_ID = 1
    static INVALID_ID = 100

    @Shared
    def client = new RESTClient("http://localhost:8080/user/")

    def "Test create user"() {
        when:
        def resp = client.post(path: 'create',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/jlson"],
                body: [
                        'firstName': "ABC",
                        'lastName' : "DEF",
                        'email'    : "abc@gmail.com",
                        'username' : "abc3",
                        'password' : "abc"
                ])
        then:
        assert resp.status == CREATED
    }

    def "Test create user with assigning user roles"() {
        when:
        def resp = client.post(path: 'create',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"],
                body: [
                        'firstName': "ABC1",
                        'lastName' : "DEF",
                        'email'    : "abc@gmail.com",
                        'username' : "abc1",
                        'password' : "abc",
                        'roles'    : [['id': 1], ['id': 2]]])
        then:
        assert resp.status == CREATED
    }

    def "Test create user with existing Username"() {
        when:
        def resp = client.post(path: 'create',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"],
                body: [
                        'firstName': "ABC1",
                        'lastName' : "DEF",
                        'email'    : "abc@gmail.com",
                        'username' : "abc1",
                        'password' : "abc"
                ])
        then:
        groovyx.net.http.HttpResponseException e = thrown()
        e.statusCode == CONFLICT
    }

    def "Test get all users"() {
        when:
        def resp = client.get(path: 'users',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"])
        then:
        assert resp.status == OK
    }

    def "Test update user"() {
        when:
        def resp = client.put(path: 'update',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"],
                body: [
                        'id'       : VALID_ID,
                        'firstName': "Demo",
                        'lastName' : "Demo",
                        'email'    : "demo@gmail.com",
                        'username' : "demo",
                        'password' : "demo"
                ])
        then:
        assert resp.status == OK
    }

    def "Test update user when given ID is invalid"() {
        when:
        def resp = client.put(path: 'update',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"],
                body: [
                        'id'       : INVALID_ID,
                        'firstName': "Demo",
                        'lastName' : "Demo",
                        'email'    : "demo@gmail.com",
                        'username' : "demo",
                        'password' : "demo"
                ])
        then:
        groovyx.net.http.HttpResponseException e = thrown()
        e.statusCode == NOT_FOUND
    }

    def "Test delete user by ID"() {
        when:
        def resp = client.delete(path: 'delete/9',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"])
        then:
        assert resp.status == NO_CONTENT
    }


    def "Test delete user by ID when given ID is invalid"() {
        when:
        def resp = client.delete(path: 'delete/' + INVALID_ID,
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"])
        then:
        groovyx.net.http.HttpResponseException e = thrown()
        e.statusCode == NOT_FOUND
    }
}
