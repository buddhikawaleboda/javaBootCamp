package com.virtusa

import groovyx.net.http.ContentType
import groovyx.net.http.RESTClient
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Stepwise


@Stepwise
class RoleRestClientSpec extends Specification {

    static OK = 200
    static CREATED = 201
    static CONFLICT = 409
    static NO_CONTENT = 204
    static NOT_FOUND = 404

    static VALID_ID = 5
    static INVALID_ID = 100

    @Shared
    def client = new RESTClient("http://localhost:8080/role/")


    def "Test create role"() {
        when:
        def resp = client.post(path: 'create',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"],
                body: ['type': "abc", 'description': "ABC"])
        then:
        assert resp.status == CREATED
    }

    def "Test create role with existing Username "() {
        when:
        def resp = client.post(path: 'create',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"],
                body: ['type': "admin", 'description': "Admin"])
        then:
        groovyx.net.http.HttpResponseException e = thrown()
        e.statusCode == CONFLICT
    }

    def "Test get all roles"() {
        when:
        def resp = client.get(path: 'roles',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"])
        then:
        assert resp.status == OK
    }

    def "Test update role"() {
        when:
        def resp = client.put(path: 'update',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"],
                body: ['id': VALID_ID, 'type': "def", 'description': "DEF",
                       'users' : [['id': 1], ['id': 2]]])
        then:
        assert resp.status == OK
    }

    def "Test update role when given ID is invalid"() {
        when:
        def resp = client.put(path: 'update',
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"],
                body: ['id': INVALID_ID, 'type': "def", 'description': "DEF",
                       'users' : [['id': 1], ['id': 2]]])
        then:
        groovyx.net.http.HttpResponseException e = thrown()
        e.statusCode == NOT_FOUND
    }

    def "Test delete role by ID"() {
        when:
        def resp = client.delete(path: 'delete/' + VALID_ID,
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"])
        then:
        assert resp.status == NO_CONTENT
    }

    def "Test delete role by ID when given ID is invalid"() {
        when:
        def resp = client.delete(path: 'delete/' + INVALID_ID,
                requestContentType: ContentType.JSON,
                headers: ['Content-Type': "application/json"])
        then:
        groovyx.net.http.HttpResponseException e = thrown()
        e.statusCode == NOT_FOUND
    }
}
