--
-- Table structure for table `purchase_order`
--

DROP TABLE IF EXISTS `purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_detail` json NOT NULL,
  `status` varchar(40) DEFAULT NULL,
  `order_uid` varchar(30) GENERATED ALWAYS AS (json_unquote(json_extract(`order_detail`,'$.orderUid'))) VIRTUAL,
  `created_on` timestamp NULL DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_uid` (`order_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
